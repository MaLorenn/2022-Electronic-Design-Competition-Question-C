/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "car.h"
#include "bsp_IR_i2c.h"
#include "stdbool.h"
#include "string.h"
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

// ?????(??:cm/s)
#define V_LEADER 22.0                // ????
#define V_FOLLOWER_STRAIGHT 38.0     // ???????
#define V_FOLLOWER_CURVE 22.0        // ??????
#define FOLLOW_DISTANCE 20.0         // ????????(cm)
#define L_TOTAL 600.0                // ????(cm)
#define DT 0.05                      // ????(?)
#define C_POSITION 450.0             // C?????(cm)
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
char rxdata[30]={0};
uint8_t rxdat;
uint8_t rx_pointer;
uint8_t ir_x1,ir_x2,ir_x3,ir_x4,ir_x5,ir_x6,ir_x7,ir_x8;
uint8_t mode=0;

float v;

int tim_temp=0;
unsigned int cnt =0;

uint32_t pul_cnt=0;
bool start_dis_cnt=0;
bool qwert=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void uart_rx_proc(void);


// ???????????
double calculate_distance(int pulses) {
    const int steps_per_rev = 200;    // ??1.8�??????????(???)
    const int microstep = 32;         // ??????
    const double diameter_cm = 6.5;   // ????(??:??)
    
    const int N = steps_per_rev * microstep;  // ???????? = 200*32 = 6400
    const double circumference = 3.1415926 * diameter_cm; // ????(cm)
    
    return (pulses * circumference) / N;  // ?????
}



// ???????????(??????)
int is_straight(double s) {
    double mod_s = fmod(s, L_TOTAL);
    return (mod_s >= 0 && mod_s < 120) ||
           (mod_s >= 180 && mod_s < 300) ||
           (mod_s >= 360 && mod_s < 480) ||
           (mod_s >= 540 && mod_s < 600);
}

// ??????????????
double distance_between(double leader, double follower) {
    return fmod((leader - follower + L_TOTAL), L_TOTAL);
}

// ???:??T_C,???????????????
double compute_total_time(double T_C) {
    double T = T_C;  // ?????(?C???)
    double s_leader = V_LEADER * T;     // ??????
    double s_follower = C_POSITION;     // ???C???

    while (distance_between(s_leader, s_follower) > FOLLOW_DISTANCE) {
        // ??????
        double v_follower = is_straight(s_follower) ? V_FOLLOWER_STRAIGHT : V_FOLLOWER_CURVE;

        // ????
        s_leader += V_LEADER * DT;
        s_follower += v_follower * DT;

        // ????
        if (s_leader >= L_TOTAL) s_leader -= L_TOTAL;
        if (s_follower >= L_TOTAL) s_follower -= L_TOTAL;

        T += DT;
    }

    return T;
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
	//en
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,1);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,0);
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_2,0);
	HAL_UART_Receive_IT(&huart1,&rxdat,1);

	while(1)   //receive mode
		{
			if(rx_pointer!=0)
			{
				int temp=rx_pointer;
				HAL_Delay(1);	
				if(temp==rx_pointer)
				{
					uart_rx_proc();
					break;
				}
			}
		}
		
		if(mode==1)
		{
			change_speed(0.3,0.3);
			forward();
			HAL_Delay(3000);//????3s ??g?????
			HAL_TIM_Base_Start_IT(&htim4); //300ms??h?????????
		
			start();
			while(1)
			{
				if(rx_pointer!=0)
				{
					int temp=rx_pointer;
					HAL_Delay(1);	
					if(temp==rx_pointer)
						uart_rx_proc();
				}
				
				Sensor(0.3);
			}
		}
		else if(mode==2)
		{
			v=0.5;
			change_speed(v,v);
			forward();
			HAL_Delay(3000);//????3s ??g?????
			HAL_TIM_Base_Start_IT(&htim4); //300ms??h?????????
		  HAL_TIM_Base_Start_IT(&htim3);
			
			start();
			
			while(1)
			{
				if(rx_pointer!=0)
				{
					int temp=rx_pointer;
					HAL_Delay(1);	
					if(temp==rx_pointer)
						uart_rx_proc();
				}
				if(qwert==1)
				{
					qwert=0;
					float dis=calculate_distance(pul_cnt);
					float t=dis/38.0; //0.38m/s
					tim_temp= (int)(compute_total_time(t)*100);
			
				}
				
				Sensor(v);
			}
		}
		
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	rxdata[rx_pointer++]=rxdat;
	HAL_UART_Receive_IT(&huart1,&rxdat,1);	
}

void uart_rx_proc(void)
{
	if(rx_pointer>0)
	{
		if(rxdata[2]=='Z' && rxdata[0]=='A')
		{
				if(rxdata[1]=='1')
				{
					mode=1;
				}
				if(rxdata[1]=='2')
				{
					mode=2;
				}
				if(rxdata[1]=='3')
				{
					HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,0);
					stop();
				}
		}
	}
	rx_pointer=0;
	memset(rxdata,0,30);
}







unsigned char tim_30ms=0;
unsigned int time_8s=0;

extern bool time_flag; 
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	
	if(htim->Instance == TIM3)
	{
		pul_cnt++;
		if((L1==1||L1==0)&&L2==0&& mid==1 &&R1==1&&R2==1)
		{
			HAL_TIM_Base_Stop_IT(&htim3);
			qwert=1;
			start_dis_cnt=1;
		}
	}
	
	if(htim->Instance == TIM4)  //10ms
	{
		if(++tim_30ms>=3)
		{
			tim_30ms=0;
			HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
			deal_IRdata(&ir_x1,&ir_x2,&ir_x3,&ir_x4,&ir_x5,&ir_x6,&ir_x7,&ir_x8);
		}
		if(++time_8s>=1400)
		{
			time_8s=0;
			time_flag=1;
		}
		
		if(start_dis_cnt==1)
		{
			if(++cnt>=tim_temp)
			{
				start_dis_cnt=0;
				cnt=0;
				v=0.3;
			}
		}

		
	}

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
