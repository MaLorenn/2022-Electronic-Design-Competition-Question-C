#ifndef __CAR_H_
#define __CAR_H_

#include "main.h"

extern uint8_t ir_x1,ir_x2,ir_x3,ir_x4,ir_x5,ir_x6,ir_x7,ir_x8;

#define  L1 ir_x1//�� 
#define  L2 ir_x2//�� 
#define stop_1 ir_x3
#define  mid ir_x4//�м�
#define stop_2 ir_x5
#define  R1 ir_x6//�� 
#define  R2 ir_x7 //�� 

void Sensor(float value);
void stop(void);
void start(void);
void back(void);
void forward(void);
void change_speed(float v1,float v2);
void Motor2_Set_angle(float angle);
void Motor1_Set_angle(float angle);
void move_linear_cm(float distance_cm);

#endif
